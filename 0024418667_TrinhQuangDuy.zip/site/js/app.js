// Câu 2: viết JavaScript tại đây

const API_URL = 'http://localhost:4000';

// Hàm có sẵn: đổi giờ UTC sang giờ Việt Nam, vd "08:00 12/09/2026"
const formatDateTime = (iso) =>
  new Date(iso).toLocaleString('vi-VN', {
    timeZone: 'Asia/Ho_Chi_Minh',
    hour: '2-digit', minute: '2-digit',
    day: '2-digit', month: '2-digit', year: 'numeric',
  });

const form = document.querySelector('#search-form');
const keywordInput = document.querySelector('#keyword');
const statusEl = document.querySelector('#status');
const listEl = document.querySelector('#event-list');

// Câu 2a: "Còn 12/40 chỗ" hoặc "Hết chỗ"
const formatSeats = (event) => {
  const remaining = event.capacity - event.registeredCount;
  return remaining > 0 ? `Còn ${remaining}/${event.capacity} chỗ` : 'Hết chỗ';
};

// Tạo một phần tử với class và văn bản (textContent, không dùng innerHTML)
const createEl = (tag, className, text) => {
  const el = document.createElement(tag);
  if (className) el.className = className;
  if (text !== undefined) el.textContent = text;
  return el;
};

const createCard = (event) => {
  const card = createEl('article', 'card');

  const img = document.createElement('img');
  img.setAttribute('src', 'img/event.svg');
  img.setAttribute('alt', `Hình minh hoạ sự kiện ${event.name}`);
  img.setAttribute('width', '320');
  img.setAttribute('height', '180');

  const body = createEl('div', 'card-body');

  const title = createEl('h2', 'card-title');
  const link = createEl('a', '', event.name);
  link.setAttribute('href', `event-detail.html?id=${encodeURIComponent(event.id)}`);
  title.append(link);

  const timeP = createEl('p', 'card-meta');
  const time = createEl('time', '', formatDateTime(event.startTime));
  time.setAttribute('datetime', event.startTime);
  timeP.append(time);

  const location = createEl('p', 'card-meta', event.location);
  const seats = createEl('p', 'card-seats', formatSeats(event));

  body.append(title, timeP, location, seats);

  if (event.registeredCount >= event.capacity) {
    body.append(createEl('span', 'badge badge-full', 'Hết chỗ'));
  }

  card.append(img, body);
  return card;
};

// Câu 2b: thay nội dung cũ của #event-list bằng các card mới
const renderEvents = (events) => {
  listEl.replaceChildren(...events.map(createCard));
};

// Câu 2c: tải dữ liệu từ API
const loadEvents = async (keyword = '') => {
  const params = new URLSearchParams({ pageSize: '50' });
  const q = keyword.trim();
  if (q !== '') params.set('q', q);

  statusEl.textContent = 'Đang tải…';

  try {
    const response = await fetch(`${API_URL}/api/events?${params}`);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);

    const data = await response.json();
    renderEvents(data.items);

    statusEl.textContent = data.items.length === 0
      ? 'Không có sự kiện nào khớp từ khoá.'
      : `Tìm thấy ${data.totalCount} sự kiện`;
  } catch (error) {
    console.error(error);
    listEl.replaceChildren();
    statusEl.textContent = 'Không tải được dữ liệu, vui lòng thử lại.';
  }
};

form.addEventListener('submit', (e) => {
  e.preventDefault();                                  // chặn tải lại trang
  loadEvents(keywordInput.value.trim());
});

loadEvents();                                          // khi mở trang
